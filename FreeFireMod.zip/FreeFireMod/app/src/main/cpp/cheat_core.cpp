#include <jni.h>
#include <string>
#include <android/log.h>
#include <sys/mman.h>
#include <unistd.h>
#include <dlfcn.h>
#include <pthread.h>

#define TAG "AlpinFFCore"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

uintptr_t libIl2cppBase = 0;

uintptr_t getModuleBase(const char* moduleName) {
    uintptr_t addr = 0;
    FILE *fp = fopen("/proc/self/maps", "r");
    if (!fp) return 0;
    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, moduleName) && strstr(line, "xp")) {
            char *p = strtok(line, "-");
            if (p) {
                addr = strtoul(p, NULL, 16);
                break;
            }
        }
    }
    fclose(fp);
    return addr;
}

void writeMemory(uintptr_t destination, void *source, size_t size) {
    long pageSize = sysconf(_SC_PAGESIZE);
    uintptr_t pageStart = destination & ~(pageSize - 1);
    mprotect((void *)pageStart, pageSize, PROT_READ | PROT_WRITE | PROT_EXEC);
    memcpy((void *)destination, source, size);
    mprotect((void *)pageStart, pageSize, PROT_READ | PROT_EXEC);
}

void* hackThread(void*) {
    while (libIl2cppBase == 0) {
        libIl2cppBase = getModuleBase("libil2cpp.so");
        usleep(1000000);
    }
    LOGI("libil2cpp base found: 0x%lx", libIl2cppBase);

    // Target Function Offset for Camera/Aim Vector (Derive using Ghidra / IDA Pro)
    uintptr_t aimVectorOffset = libIl2cppBase + 0x2B48C10;
    
    // ARM64 patch instruction sequence
    unsigned int patchCode = 0x1E200000; 
    writeMemory(aimVectorOffset, &patchCode, sizeof(patchCode));
    
    return NULL;
}

extern "C" JNIEXPORT void JNICALL
Java_com_alpin_mod_OverlayService_nativeStartHook(JNIEnv *env, jobject thiz) {
    pthread_t t;
    pthread_create(&t, NULL, hackThread, NULL);
}
